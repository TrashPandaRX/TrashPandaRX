package com.caveofprogramming.oceangame;

public class Aquarium {

}
