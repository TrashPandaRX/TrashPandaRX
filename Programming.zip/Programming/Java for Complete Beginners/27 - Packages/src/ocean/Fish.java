package ocean;

public class Fish {

}
