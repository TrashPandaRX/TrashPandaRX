package ocean.plants;

public class Algae {

}
