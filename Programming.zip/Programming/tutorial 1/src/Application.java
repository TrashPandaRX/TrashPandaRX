
public class Application {

	public static void main(String[] args) {
		int blunderDump = 88;
		short myShort = 133;
		long myLong = 6449;
				
		double myDibble = 21.3164;
		float myBoat = 278.6f;
		
		char myFool = 'y';
		boolean myBoolean = false;
				
		byte myBitter = 127;
		
		System.out.println(blunderDump);
		System.out.println(myShort);
		System.out.println(myLong);
		System.out.println(myDibble);
		System.out.println(myBoat);
		System.out.println(myFool);
		System.out.println(myBoolean);
		System.out.println(myBitter);
	}

}
