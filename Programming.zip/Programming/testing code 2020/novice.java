public class novice
{
	public static void main(String[] args)
	{
		int n = 10;
		int i;
		
		for (i = 1; i <= n; i++)	//i fucked up, originally had the second stament say "i == n" which means it will only run while THE SECOND STATEMENT IS TRUE
		{
			System.out.println("current # is: " + i);
		}
	}
}