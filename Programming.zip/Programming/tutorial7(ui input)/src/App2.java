import java.util.Scanner;

public class App2 {
	public static void main(String[] args) {
		// This is a variation of app where we utilize an integer instead of a text. you cant use
		// both integers and text as you would cause it to crash because program isn't that robust...
		// Create scanner object
		Scanner input = new Scanner(System.in);
		
		// Output the prompt
		System.out.println("Enter an integer: ");
		
		// Wait for the user to enter something
		int value = input.nextInt();
		
		// Tell them what they entered
		System.out.println("You entered: " + value);
	}
}