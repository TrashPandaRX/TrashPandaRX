
public class ApplicationD {
	public static void main(String[] args) {
		
		int myInt = 15;
		
		if(myInt < 10) {
			System.out.println("Yes, it's true!");
		}
		else if(myInt > 20) {
			System.out.println("No, it's false!");
		}
		else {
			System.out.println("None of the above");
		}
		//* In this particular example if run, this OUGHT to show "none of the above" in the run box, because
		//* neither of the first 2 conditionals are correct. if we set myInt to 5 then the first condition
		//* would be true. and if we set it to greater than 20, then the second condition would be true.
		//* if the setup were:
		//*		int myInt = 5;
		//*
		//* 	if(myInt < 10) {
		//*			System.out.println("Yes, it's true!");
		//*		}
		//*		else if(myInt < 20) {
		//*			System.out.println("No, it's false!");
		//*		}
		//* Both conditionals are TRUE, however the computer disregards the second conditional, aka
		//* the "else if" condition because "else" only triggers if the initial conditional, the "if" is
		//* is considered false. But in this case the "if" is true, so "else if" is ignored.
		//*
	}
}
	
	//* 	boolean cond = 4 == 3;
	//*  == and = are totally different. == means you are testing for equality,
	//* while = means you are setting something equal to something else
	//* if you have something like: boolean cond = 5 != 5, the ! means NOT. so ! =5 is saying
	//* 5 IS NOT equal to 5, running that with a sysout ought to have nothing appear in the run
	//* 	System.out.println(cond);