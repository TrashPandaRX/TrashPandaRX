import java.util.Scanner;

public class SieveRunner
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		Sieve sieve = new Sieve();

		System.out.println("Please enter a number less than 500 to determine all of its primes");

		int getMyPrimes = scanner.nextInt();

		sieve.primer(getMyPrimes);
		sieve.elimTwos(sieve.getIs_Prime());
		sieve.primeList(sieve.getIs_Prime());

		System.out.println(sieve.getIs_Prime());
	}
}