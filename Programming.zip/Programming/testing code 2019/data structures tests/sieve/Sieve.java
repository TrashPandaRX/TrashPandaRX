import java.util.ArrayList;
import java.lang.Math.*;

//find all prime numbers from up to the input value, and place them in the ArrayList
public class Sieve
{
	/*
		Initialize the array (is_prime)

		Eliminate multiples of 2

		For p=3 to sqrt(N), Step 2
			~Make sure p is prime.
			If (is_prime[p]) Then
				~Cross out multiples of p
				For multiple = p * p to N, Step 2 * p
					is_prime[multiple] = False
				Next multiple
			End If
		Next p
	*/

	/*--------------------setting the arraylist up--------------------------*/

	private ArrayList<Integer> is_prime = new ArrayList<Integer>();

	//getter
	public ArrayList<Integer> getIs_Prime()
	{
		return this.is_prime;
	}


	//adds numbers to the arraylist
	public void primer (int maximum)
	{
		int start_value = 2;
		for (int counter = 0; start_value <= maximum; counter++)
		{
			is_prime.add(start_value);
			start_value++;
		}
	}

	/*--------------------eliminate multiples of 2--------------------------*/
	public void elimTwos (ArrayList<Integer> hasTwos)
	{
		//indidice starts at index 2 because indicies 0 & then 1 are designed to hold 2 & 3 respectively; so we effectively start at 4...if the input is even that small
		for (int indicie = 1; indicie <= hasTwos.size()-1; indicie = indicie+1)
		{
			//if the value at the indicie is divisible by two, remove it
			if (hasTwos.get(indicie)%2 == 0)
			{
				hasTwos.remove(indicie);
			}
		}
	}

	/*--------------------elimination check if indicie is prime & also elim multiples of primes--------------------------*/
	public void primeList (ArrayList<Integer> twosRemoved)
	{
		int p = 3;	//current prime #
		int currentSpot = 1;	//ideally you use this method after running elimTwos. otherwise you will have a hot mess.
		Factorization primeChecker = new Factorization();

		while (p <= Math.sqrt(twosRemoved.get(currentSpot)))
		{
			primeChecker.primeFactors(twosRemoved.get(currentSpot));
			
			if (primeChecker.getFactorable().size() == 1)
			{
				for (int multiple = p*p; multiple <= Math.sqrt(twosRemoved.get(currentSpot)); multiple = (p+1)*p)
				{
					if (multiple <= twosRemoved.get(twosRemoved.size()-1))
					{
						twosRemoved.remove(currentSpot);
					}
				}
			}
			currentSpot++;
			p++;
		}
	}






}