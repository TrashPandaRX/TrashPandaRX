import java.util.ArrayList;
import java.lang.Math.*;

public class Factorization
{
	private ArrayList<Integer> factorable = new ArrayList<Integer>();

	//add method, that adds an integer to an arraylist<Integer> of factorable numbers
	//this might not be needed...since arraylist has this method built in, PS this is essentially a setter
	/*
	public void add (int addValue)
	{
		factorable.add(addValue);
	}
	*/

	//this is a BAD prime number checker, as it is only accurate up to 10,000. *** WRONG, actually this only
	//works if one of the prime numbers that makes up the number we are checking is 2,3,5 or 7.
	//ANYTHING BEYOND those 4 results in WRONG answers
	/*
	public boolean factorCheck(int factorCheckValue)
	{
		if (factorCheckValue < 10 && factorCheckValue > 0)	//all ints between 0 & 10, excluding 0 and 10
		{
			if (factorCheckValue == 2 ||factorCheckValue == 3 || factorCheckValue == 5 || factorCheckValue == 7)
			{
				return true;	//is a prime #
			}
			else
			{
				return false;	//is NOT a prime #
			}
		}
		else if (factorCheckValue%2 == 0 || factorCheckValue%3 == 0 || factorCheckValue%5 == 0 || factorCheckValue%7 == 0)
		{
			return false;
		}
		else
		{
			return true;
		}

		while (factorCheckValue)
		{
			switch()
			{
				case :
				{

					break;
				}

				case :
				{

					break;
				}
			}
		}












































	}
	*/

	//we also need a method that actually takes in a number and sequentially checks for
	//different prime numbers of the number and adds that number to the arraylist of prime factors

	public void primeFactors(int factorMe)
	{
		//takes care of multiples of 2
		while (factorMe%2 == 0)		//theres a factor of 2
		{
			factorable.add(2);
			factorMe = factorMe/2;
		}
		int factor = 3;
		double stop_at = Math.sqrt(factorMe);
		while(factor <= stop_at)
		{
			while(factorMe%factor == 0)
			{
				factorable.add(factor);
				factorMe = factorMe/factor;

				//calculating a new stop_at value
				stop_at = Math.sqrt(factorMe);
			}
			factor = factor+2;	//lets you skip multiples of 2, since they would have already been handled by the first while loop
		}
		if (factorMe>1)
		{
			factorable.add(factorMe);
		}
	}

	//getter for factorable
	public ArrayList<Integer> getFactorable ()
	{
		return this.factorable;
	}



}