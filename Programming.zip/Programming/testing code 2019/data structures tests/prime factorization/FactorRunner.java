import java.util.Scanner;

public class FactorRunner
{
	public static void main (String[]args)
	{
		System.out.println("Please type an integer:");
		
		Scanner scanner = new Scanner(System.in);
		int input = scanner.nextInt();

		Factorization prime = new Factorization();

		
		//determines if it is prime
		/*
		while (input != -1)
		{
			boolean isItPrime = prime.factorCheck(input);
			if (isItPrime == true)
			{
				System.out.println(input + " is a prime number");
			}
			else
			{
				System.out.println(input + " is NOT a prime number");
			}

			input = scanner.nextInt();
		}

		if (input == -1)
		{
			System.out.println("Ending program");
			System.exit(-1);
		}
		*/

		//yanks out the factors of a number using multiple iteration
		
		prime.primeFactors(input);
		System.out.println(prime.getFactorable());

		//checks to see if the number is prime based on its list of factors. if there is only 1 indicie, then that means the number is only able to be obtained by multiplying itself by 1.
		if (prime.getFactorable().size() == 1)
		{
			System.out.println(input + " is a prime number");
		}
		
	}
}