public class Triangle
{
	
}